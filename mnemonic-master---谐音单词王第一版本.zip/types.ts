export interface PhoneticPart {
  syllable: string;
  soundAlike: string;
}

export interface ExampleSentence {
  english: string;
  chinese: string;
}

export interface MnemonicOption {
  style: string; // e.g., "Standard", "Absurd", "Ancient", "Slang"
  breakdown: PhoneticPart[];
  mnemonic: string;
  explanation: string;
}

export interface Definition {
  pos: string; // Part of speech (n., v., adj.)
  text: string; // The meaning
}

export interface WordData {
  word: string;
  pronunciation: string; // IPA
  definitions: Definition[]; // Changed from single string to array
  options: MnemonicOption[];
  examples: ExampleSentence[];
  timestamp?: number; // Added for sorting favorites
}

export enum AppState {
  IDLE,
  ANALYZING,
  COMPLETE,
  ERROR
}