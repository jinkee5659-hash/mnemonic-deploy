import React, { useState, useEffect } from 'react';
import { WordData, PhoneticPart } from '../types';
import BlurReveal from './BlurReveal';

interface ResultCardProps {
  data: WordData;
  onNext?: () => void;
  onPrev?: () => void;
  showNav?: boolean;
  onToggleFavorite: (word: string) => void;
  isFavorite: boolean;
  onUpdateData: (newData: WordData) => void;
}

// Helper to play high-quality audio
const playHighQualityAudio = (text: string) => {
  const audio = new Audio(`https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=en&q=${encodeURIComponent(text)}`);
  
  audio.play().catch((err) => {
    console.warn("Google TTS failed, falling back to browser synthesis", err);
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US';
    window.speechSynthesis.speak(utterance);
  });
  return audio;
};

// Helper component for individual example rows
const ExampleRow: React.FC<{ example: { english: string; chinese: string } }> = ({ example }) => {
  const [isPlaying, setIsPlaying] = useState(false);

  const playSentence = () => {
    if (isPlaying) return;
    setIsPlaying(true);
    
    const audio = playHighQualityAudio(example.english);
    
    audio.onended = () => setIsPlaying(false);
    audio.onerror = () => setIsPlaying(false);
    setTimeout(() => setIsPlaying(false), 5000);
  };

  return (
    <div className="border-l-4 border-yellow-400 pl-4 py-3 hover:bg-yellow-50/50 transition-colors rounded-r-lg group/row mb-3 last:mb-0">
      <div className="flex items-start justify-between gap-3">
        <p className="text-slate-800 font-medium text-lg leading-snug flex-1 font-nunito">{example.english}</p>
        <button 
          onClick={playSentence}
          disabled={isPlaying}
          className="flex-shrink-0 w-8 h-8 flex items-center justify-center rounded-full bg-slate-100 hover:bg-purple-100 text-slate-400 hover:text-purple-600 transition-all active:scale-95"
        >
          {isPlaying ? <i className="fas fa-spinner animate-spin text-purple-600"></i> : <i className="fas fa-volume-up text-sm"></i>}
        </button>
      </div>
      <div className="mt-2 block">
        <BlurReveal text={example.chinese} className="text-slate-600 leading-relaxed text-base" blurText="点击翻译" />
      </div>
    </div>
  );
};

const ResultCard: React.FC<ResultCardProps> = ({ 
  data, 
  onNext, 
  onPrev, 
  showNav, 
  onToggleFavorite, 
  isFavorite,
  onUpdateData
}) => {
  const [selectedOptionIndex, setSelectedOptionIndex] = useState(0);
  const [playingAudio, setPlayingAudio] = useState<'US' | 'UK' | null>(null);
  
  // Edit Mode State
  const [isEditing, setIsEditing] = useState(false);
  const [editBreakdown, setEditBreakdown] = useState<PhoneticPart[]>([]);
  const [editMnemonic, setEditMnemonic] = useState('');

  // Reset/Initialize when data changes
  useEffect(() => {
    // If user has a preferred option saved in local storage (separate from favoriting), we could load it here.
    // For now, default to 0. 
    // Ideally, we persist the selected index preference too, but let's stick to the prompt.
    setSelectedOptionIndex(0);
    setIsEditing(false);
  }, [data.word]);

  // Sync edit state when option changes
  useEffect(() => {
    const currentOption = data.options[selectedOptionIndex];
    if (currentOption) {
      setEditBreakdown(JSON.parse(JSON.stringify(currentOption.breakdown)));
      setEditMnemonic(currentOption.mnemonic);
    }
  }, [selectedOptionIndex, data.options]);

  const handleSaveEdit = () => {
    const newData = JSON.parse(JSON.stringify(data)) as WordData;
    newData.options[selectedOptionIndex].breakdown = editBreakdown;
    newData.options[selectedOptionIndex].mnemonic = editMnemonic;
    
    onUpdateData(newData);
    setIsEditing(false);
  };

  const handleCancelEdit = () => {
    const currentOption = data.options[selectedOptionIndex];
    setEditBreakdown(JSON.parse(JSON.stringify(currentOption.breakdown)));
    setEditMnemonic(currentOption.mnemonic);
    setIsEditing(false);
  };

  const colors = [
    { bg: 'bg-red-50', text: 'text-red-500', border: 'border-red-400', title: 'text-gray-700' },
    { bg: 'bg-blue-50', text: 'text-blue-500', border: 'border-blue-400', title: 'text-gray-700' },
    { bg: 'bg-green-50', text: 'text-green-500', border: 'border-green-400', title: 'text-gray-700' },
    { bg: 'bg-purple-50', text: 'text-purple-500', border: 'border-purple-400', title: 'text-gray-700' },
    { bg: 'bg-orange-50', text: 'text-orange-500', border: 'border-orange-400', title: 'text-gray-700' },
  ];

  const playWordAudio = async (accent: 'US' | 'UK') => {
    if (playingAudio) return;
    setPlayingAudio(accent);

    try {
      let played = false;
      try {
        const res = await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${data.word}`);
        if (res.ok) {
          const apiData = await res.json();
          const phonetics = apiData[0]?.phonetics || [];
          const match = phonetics.find((p: any) => 
            p.audio && (accent === 'US' ? p.audio.includes('-us') : p.audio.includes('-uk'))
          );
          if (match && match.audio) {
             const audio = new Audio(match.audio);
             await audio.play();
             played = true;
          }
        }
      } catch (err) {}

      if (!played) {
         await new Promise<void>((resolve) => {
            const audio = playHighQualityAudio(data.word);
            audio.onended = () => resolve();
            audio.onerror = () => resolve();
            setTimeout(resolve, 3000);
         });
      }
    } catch (e) {
    } finally {
      setPlayingAudio(null);
    }
  };

  // Parser to split text by {{...}} and render BlurReveal components
  const renderMnemonicSentence = (text: string) => {
    // Regex to capture content inside {{ }}
    const parts = text.split(/(\{\{.*?\}\})/g);
    
    return (
      <>
        {parts.map((part, index) => {
          if (part.startsWith('{{') && part.endsWith('}}')) {
            // Extract content without braces
            const content = part.slice(2, -2);
            return (
              <BlurReveal 
                key={index} 
                text={content} 
                className="text-yellow-600 font-bold mx-1 border-b-2 border-yellow-300 border-dashed"
                blurText="" // No text, just icon for inline
              />
            );
          }
          return <span key={index}>{part}</span>;
        })}
      </>
    );
  };

  const currentOption = data.options[selectedOptionIndex];
  // Check if current style is the first option (formerly Standard/Logical)
  const isStandard = selectedOptionIndex === 0;

  return (
    <div className="w-full max-w-4xl mx-auto bg-white rounded-[2rem] shadow-2xl overflow-hidden border-4 border-yellow-100 animate-fade-in-up flex flex-col relative min-h-[600px]">
      
      {/* Navigation Overlay Arrows for Vocab Mode */}
      {showNav && (
        <>
          <button onClick={onPrev} className="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-12 h-12 bg-white/90 hover:bg-white rounded-full shadow-lg flex items-center justify-center text-slate-400 hover:text-yellow-600 transition-all border border-slate-100 active:scale-90">
            <i className="fas fa-chevron-left text-lg"></i>
          </button>
          <button onClick={onNext} className="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-12 h-12 bg-white/90 hover:bg-white rounded-full shadow-lg flex items-center justify-center text-slate-400 hover:text-yellow-600 transition-all border border-slate-100 active:scale-90">
            <i className="fas fa-chevron-right text-lg"></i>
          </button>
        </>
      )}

      {/* 1. Header Section */}
      <div className="bg-yellow-400 p-6 md:p-8 text-center relative overflow-hidden flex-shrink-0">
        <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
          <i className="fas fa-quote-right text-8xl absolute -top-4 -left-4 text-white"></i>
          <i className="fas fa-lightbulb text-8xl absolute -bottom-4 -right-4 text-white"></i>
        </div>
        
        <h1 className="text-5xl lg:text-6xl font-black text-slate-900 tracking-wide mb-3 relative z-10 capitalize font-display">
          {data.word}
        </h1>
        
        <div className="flex flex-col items-center gap-3 relative z-10">
          <span className="font-mono text-xl tracking-wide bg-white/20 px-4 py-1 rounded-full">{data.pronunciation}</span>

          <div className="flex items-center gap-3 mt-1">
            <button 
              onClick={() => playWordAudio('US')}
              disabled={!!playingAudio}
              className="group flex items-center gap-2 bg-white/30 hover:bg-white/50 px-3 py-1.5 rounded-full transition-all active:scale-95 disabled:opacity-50 min-w-[70px] justify-center"
            >
              {playingAudio === 'US' ? <i className="fas fa-spinner animate-spin"></i> : <i className="fas fa-volume-up"></i>}
              <span className="text-xs font-bold">美式</span>
            </button>
            <button 
              onClick={() => playWordAudio('UK')}
              disabled={!!playingAudio}
              className="group flex items-center gap-2 bg-white/30 hover:bg-white/50 px-3 py-1.5 rounded-full transition-all active:scale-95 disabled:opacity-50 min-w-[70px] justify-center"
            >
              {playingAudio === 'UK' ? <i className="fas fa-spinner animate-spin"></i> : <i className="fas fa-volume-up"></i>}
              <span className="text-xs font-bold">英式</span>
            </button>
          </div>
        </div>

        {/* Structured Definitions with Blur */}
        <div className="mt-4 space-y-2 max-w-lg mx-auto bg-white/20 p-4 rounded-xl backdrop-blur-sm">
           {data.definitions && data.definitions.length > 0 ? (
             data.definitions.map((def, idx) => (
               <div key={idx} className="flex gap-2 items-start justify-center">
                 <span className="font-bold text-slate-800 bg-white/40 px-2 rounded text-sm min-w-[30px] self-center">{def.pos}</span>
                 <BlurReveal text={def.text} className="text-slate-900 font-bold text-lg" blurText="点击查看释义" />
               </div>
             ))
           ) : (
             <p className="text-2xl font-bold text-slate-900">{(data as any).meaning}</p>
           )}
        </div>
      </div>

      {/* 2. Mnemonic Content Section */}
      <div className="p-6 md:p-8 bg-white flex-grow flex flex-col justify-center">
        
        {/* 5 Options Selector */}
        {data.options.length > 0 && (
          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {data.options.map((opt, idx) => {
              const label = `谐音 ${idx + 1}`;
              return (
                <button
                  key={idx}
                  onClick={() => setSelectedOptionIndex(idx)}
                  className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all border-2 ${
                    selectedOptionIndex === idx 
                      ? 'bg-yellow-400 border-yellow-400 text-slate-900 shadow-md scale-105' 
                      : 'bg-transparent border-slate-200 text-slate-500 hover:border-yellow-300 hover:text-yellow-600'
                  }`}
                >
                  {label}
                </button>
              );
            })}
          </div>
        )}

        <div className="animate-fade-in relative">
           
           {/* Favorites Button */}
           <button 
             onClick={() => onToggleFavorite(data.word)}
             className={`absolute right-0 -top-2 w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 shadow-sm border ${
               isFavorite 
                ? 'bg-pink-50 border-pink-200 text-pink-500' 
                : 'bg-slate-50 border-slate-100 text-slate-300 hover:text-pink-300'
             }`}
             title={isFavorite ? "取消收藏" : "收藏此脑洞"}
           >
             <i className={`fas fa-heart text-lg ${isFavorite ? 'animate-pulse' : ''}`}></i>
           </button>

           {/* Edit Button */}
           <button 
             onClick={() => setIsEditing(!isEditing)}
             className={`absolute left-0 -top-2 w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 shadow-sm border bg-slate-50 border-slate-100 text-slate-300 hover:text-blue-500 hover:border-blue-200`}
             title="自定义修改"
           >
             <i className={`fas fa-pencil-alt text-sm`}></i>
           </button>

           <div className="text-center mb-2">
              <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">
                {isEditing ? '自定义编辑模式' : '谐音联想 · 记忆魔法'}
              </p>
           </div>

           {/* Syllable Breakdown */}
           <div className="flex flex-wrap justify-center items-stretch gap-3 mb-8">
             {isEditing ? (
               <div className="w-full space-y-3">
                 {editBreakdown.map((part, idx) => (
                   <div key={idx} className="flex gap-2 items-center justify-center">
                      <div className="w-16 font-display font-black text-xl text-slate-400 text-right">{part.syllable}</div>
                      <i className="fas fa-arrow-right text-slate-300 text-xs"></i>
                      <input 
                        type="text" 
                        value={part.soundAlike}
                        onChange={(e) => {
                          const newParts = [...editBreakdown];
                          newParts[idx].soundAlike = e.target.value;
                          setEditBreakdown(newParts);
                        }}
                        className="border-2 border-slate-200 rounded-lg px-3 py-2 w-32 focus:border-yellow-400 outline-none font-bold text-slate-700"
                      />
                   </div>
                 ))}
               </div>
             ) : (
               currentOption.breakdown.map((part, idx) => {
                 const colorStyle = colors[idx % colors.length];
                 return (
                   <div key={idx} className={`flex-1 min-w-[90px] max-w-[140px] ${colorStyle.bg} rounded-2xl p-3 border-b-4 ${colorStyle.border} hover:-translate-y-1 transition-transform duration-300 shadow-sm`}>
                     <div className={`text-2xl font-black ${colorStyle.text} mb-1 text-center font-display`}>{part.syllable}</div>
                     <div className={`text-lg font-bold ${colorStyle.title} text-center`}>“{part.soundAlike}”</div>
                   </div>
                 );
               })
             )}
           </div>

           {/* The Story */}
           <div className="bg-slate-50 rounded-2xl p-8 border-2 border-slate-100 mb-8 relative min-h-[160px] flex flex-col justify-center items-center">
              {!isEditing && (
                <div className="absolute -top-3 left-6 bg-yellow-400 text-xs font-bold px-2 py-1 rounded text-slate-900 uppercase">
                  {currentOption.style} (谐音 {selectedOptionIndex + 1})
                </div>
              )}
              
              <div className="w-full text-center">
                 {isEditing ? (
                   <textarea
                      value={editMnemonic}
                      onChange={(e) => setEditMnemonic(e.target.value)}
                      className="w-full h-32 p-3 border-2 border-slate-200 rounded-xl focus:border-yellow-400 outline-none text-lg text-slate-700 resize-none"
                      placeholder="编辑助记句..."
                   />
                 ) : (
                   <p className="text-xl text-slate-800 leading-relaxed font-medium font-noto">
                      {renderMnemonicSentence(currentOption.mnemonic)}
                   </p>
                 )}
              </div>

              {isEditing && (
                <div className="flex gap-3 mt-4">
                  <button onClick={handleCancelEdit} className="px-4 py-2 rounded-lg bg-slate-200 text-slate-600 font-bold hover:bg-slate-300">取消</button>
                  <button onClick={handleSaveEdit} className="px-4 py-2 rounded-lg bg-yellow-400 text-slate-900 font-bold hover:bg-yellow-500 shadow-md">保存修改</button>
                </div>
              )}

              {/* Logic for Standard Style hiding explanation */}
              {!isStandard && !isEditing && (
                <div className="mt-4 text-center text-sm text-slate-500 italic bg-white p-3 rounded-lg border border-slate-100 w-full">
                   💡 {currentOption.explanation}
                </div>
              )}
           </div>

           {/* Example Sentences */}
           {!isEditing && data.examples && data.examples.length > 0 && (
             <div className="max-w-3xl mx-auto">
               <h3 className="text-slate-400 text-xs font-bold uppercase tracking-widest text-center mb-4">场景例句 · 点读</h3>
               <div className="space-y-4">
                 {data.examples.map((ex, idx) => (
                   <ExampleRow key={idx} example={ex} />
                 ))}
               </div>
             </div>
           )}
        </div>
      </div>
    </div>
  );
};

export default ResultCard;