import React, { useState, useEffect } from 'react';

interface BlurRevealProps {
  text: string;
  className?: string;
  blurText?: string;
}

const BlurReveal: React.FC<BlurRevealProps> = ({ text, className = "", blurText }) => {
  const [isRevealed, setIsRevealed] = useState(false);

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;
    if (isRevealed) {
      timer = setTimeout(() => {
        setIsRevealed(false);
      }, 5000);
    }
    return () => clearTimeout(timer);
  }, [isRevealed]);

  // Use span for inline support
  return (
    <span 
      onClick={(e) => {
        e.stopPropagation();
        setIsRevealed(true);
      }}
      className={`relative inline-flex items-center justify-center transition-all duration-500 cursor-pointer select-none align-bottom rounded px-1 mx-0.5 ${className}
        ${isRevealed ? 'filter-none opacity-100 bg-transparent' : 'bg-slate-200/50'}`}
      title="点击查看"
    >
      <span className={`transition-all duration-500 ${isRevealed ? 'blur-0 opacity-100 text-inherit' : 'blur-sm opacity-0 text-transparent'}`}>
        {text}
      </span>
      
      {/* Fallback placeholder text when blurred (if provided), otherwise just blur shape */}
      {!isRevealed && blurText && (
         <span className="absolute inset-0 flex items-center justify-center text-[10px] text-slate-400 font-bold">
           {blurText}
         </span>
      )}
      {!isRevealed && !blurText && (
         <span className="absolute inset-0 flex items-center justify-center text-slate-400/50 text-xs">
           <i className="fas fa-eye-slash"></i>
         </span>
      )}
    </span>
  );
};

export default BlurReveal;