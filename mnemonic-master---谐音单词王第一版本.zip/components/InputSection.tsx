import React, { useState } from 'react';

interface InputSectionProps {
  onSearch: (word: string) => void;
  isLoading: boolean;
}

const InputSection: React.FC<InputSectionProps> = ({ onSearch, isLoading }) => {
  const [input, setInput] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) {
      onSearch(input.trim());
    }
  };

  return (
    <div className="w-full max-w-xl mx-auto mb-8">
      <form onSubmit={handleSubmit} className="relative">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="输入英语单词 (例如: Ambulance)"
          className="w-full px-6 py-4 text-lg rounded-full shadow-lg border-2 border-transparent focus:border-purple-500 focus:outline-none transition-all duration-300 pr-32 bg-white/90 backdrop-blur-sm text-slate-800 placeholder-slate-400"
          disabled={isLoading}
        />
        <button
          type="submit"
          disabled={isLoading || !input.trim()}
          className="absolute right-2 top-2 bottom-2 bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-6 rounded-full font-semibold hover:shadow-md disabled:opacity-50 disabled:cursor-not-allowed transition-all transform hover:scale-105 active:scale-95"
        >
          {isLoading ? (
            <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
          ) : (
            '开始记忆'
          )}
        </button>
      </form>
      <p className="text-center mt-3 text-sm text-slate-500">
        热门单词: <span className="font-mono text-purple-600 bg-purple-100 px-1 rounded mx-1 cursor-pointer" onClick={() => onSearch('Ambulance')}>Ambulance</span> 
        <span className="font-mono text-purple-600 bg-purple-100 px-1 rounded mx-1 cursor-pointer" onClick={() => onSearch('Pest')}>Pest</span> 
        <span className="font-mono text-purple-600 bg-purple-100 px-1 rounded mx-1 cursor-pointer" onClick={() => onSearch('Generous')}>Generous</span>
      </p>
    </div>
  );
};

export default InputSection;