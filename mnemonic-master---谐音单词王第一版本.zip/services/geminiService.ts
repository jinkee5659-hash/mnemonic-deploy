import { GoogleGenAI, Type, Schema } from "@google/genai";
import { WordData } from "../types";

// Initialize the client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const responseSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    word: { type: Type.STRING, description: "The original English word" },
    pronunciation: { type: Type.STRING, description: "IPA pronunciation (e.g., /dʒen.ər.əs/)" },
    definitions: {
      type: Type.ARRAY,
      description: "List of definitions separated by part of speech",
      items: {
        type: Type.OBJECT,
        properties: {
          pos: { type: Type.STRING, description: "Part of speech (e.g., n., v., adj.)" },
          text: { type: Type.STRING, description: "Chinese meaning for this part of speech" },
        },
        required: ["pos", "text"],
      }
    },
    options: {
      type: Type.ARRAY,
      description: "Exactly 5 different mnemonic options with different styles",
      items: {
        type: Type.OBJECT,
        properties: {
          style: { type: Type.STRING, description: "The style of this mnemonic (e.g., 'Standard', 'Absurd', 'Ancient', 'Slang', 'Visual')" },
          breakdown: {
            type: Type.ARRAY,
            description: "Phonetic breakdown specific to this mnemonic",
            items: {
              type: Type.OBJECT,
              properties: {
                syllable: { type: Type.STRING, description: "English syllable (e.g., Ge)" },
                soundAlike: { type: Type.STRING, description: "Chinese sound-alike character (e.g., 街)" },
              },
              required: ["syllable", "soundAlike"],
            },
          },
          mnemonic: { type: Type.STRING, description: "The full mnemonic sentence. IMPORTANT: Enclose the ACTUAL Chinese definition of the English word within {{ and }}. Example: ...这也太{{慷慨}}了！" },
          explanation: { type: Type.STRING, description: "Brief explanation of the memory aid in Chinese" },
        },
        required: ["style", "breakdown", "mnemonic", "explanation"],
      },
    },
    examples: {
      type: Type.ARRAY,
      description: "2 example sentences showing how the word is used in context",
      items: {
        type: Type.OBJECT,
        properties: {
          english: { type: Type.STRING, description: "English sentence" },
          chinese: { type: Type.STRING, description: "Chinese translation" },
        },
        required: ["english", "chinese"],
      },
    },
  },
  required: ["word", "pronunciation", "definitions", "options", "examples"],
};

const wait = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Fallback data when quota is exceeded so the app doesn't crash
const getQuotaExceededData = (word: string): WordData => ({
  word: word,
  pronunciation: "/ˈkwoʊ.tə/",
  definitions: [{ pos: "Error", text: "API 额度耗尽" }],
  options: Array(5).fill(null).map((_, i) => ({
    style: ["常规", "荒诞", "古风", "热梗", "视觉"][i],
    breakdown: [
      { syllable: "Quo", soundAlike: "抠" }, 
      { syllable: "ta", soundAlike: "他" }
    ],
    mnemonic: `Google API 太{{抠他}}钱了，免费额度（每分钟15次）已用完。请稍等几秒再试！`,
    explanation: "您触发了 Gemini API 的免费调用频率限制。这通常在几十秒后自动恢复。"
  })),
  examples: [
    { english: "The API quota has been exhausted.", chinese: "API 调用次数已达上限。" },
    { english: "Please wait a moment and try again.", chinese: "请稍等片刻重试。" }
  ]
});

export const analyzeWord = async (word: string, retryCount = 0): Promise<WordData> => {
  try {
    const model = "gemini-2.5-flash";
    const systemInstruction = `
      You are an expert 'English Word Sound-alike Association Master' (英语单词谐音联想记忆大师). 
      Your goal is to help users memorize English words by breaking them down into phonetic parts that sound like Chinese words/characters, 
      and then constructing a funny, absurd, or visually strong sentence that links these Chinese sounds to the English word's meaning.

      Capabilities:
      1. Phonetic Breakdown: Split word into syllables.
      2. Chinese Sound-alike: Find Chinese characters that sound similar to each syllable.
      3. Scene Construction: Create a sentence using the Chinese characters that hints at the English meaning.

      Constraints:
      1. Provide EXACTLY 5 DIFFERENT mnemonic variations (options).
      2. The 5 variations must follow these specific styles:
         - Option 1: Standard/Logical (常规谐音) - Focus on simple, direct sound links.
         - Option 2: Absurd/Nonsense (荒诞无厘头) - Example: bath -> "白丝" (wearing white silk stockings to take a bath? Absurd!)
         - Option 3: Ancient Chinese/Poetic (古文风) - Use archaic terms if possible.
         - Option 4: Internet Slang/Meme (网络热梗) - Use Gen-Z slang.
         - Option 5: Visual Impact (视觉暴击) - Highly descriptive and weird.
      3. Provide IPA pronunciation.
      4. Provide 2 common example sentences.
      5. Provide definitions separated by part of speech (e.g., n. vs v.).
      
      CRITICAL INSTRUCTION FOR MNEMONIC SENTENCE:
      You MUST wrap the actual Chinese translation/meaning of the target English word inside double curly braces {{ }}.
      
      Example:
      Word: Generous (慷慨)
      Breakdown: Ge (街) - ne (拿) - rous (肉丝)
      Mnemonic: "大街上居然可以随便拿肉丝？这也太{{慷慨}}了！"
      
      Word: Pest (害虫)
      Breakdown: Pe (拍) - st (死它)
      Mnemonic: "看到这只{{害虫}}，我就想一巴掌拍死它！"
    `;

    const prompt = `Analyze the word: "${word}". Provide 5 distinct mnemonic options (Standard, Absurd, Ancient, Slang, Visual) in strict JSON format.`;

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 1.2, // High creativity for puns
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");
    
    return JSON.parse(text) as WordData;
  } catch (error: any) {
    // Retry logic for 429 (Resource Exhausted) or 5xx errors
    // Limit retries to 3 to prevent infinite loops
    if (retryCount < 3 && (
        error.message?.includes('429') || 
        error.status === 429 || 
        error.message?.includes('quota') || 
        error.message?.includes('503') ||
        error.code === 500 // RPC errors often appear as 500/Unknown
      )) {
      
      // Tuned delays: 4s, 8s, 12s (Previous were too short for 15 RPM limit)
      const delay = (retryCount + 1) * 4000; 
      console.warn(`API Error for "${word}" (Attempt ${retryCount + 1}). Retrying in ${delay}ms...`, error.message);
      await wait(delay);
      return analyzeWord(word, retryCount + 1);
    }
    
    // Fallback: If quota is truly exhausted after retries, return mock data
    // This allows the UI to stay interactive and informs the user gracefully
    if (error.message?.includes('429') || error.message?.includes('quota') || error.status === 429) {
      console.error("Quota exhausted after retries. Returning fallback data.");
      return getQuotaExceededData(word);
    }
    
    console.error("Final Text Generation Error:", error);
    throw error;
  }
};