// A curated list of intermediate/advanced words (removing basic vocabulary)
// Simulating a "3000 Essential Words" book
export const vocabList = [
  "Serendipity",
  "Ephemeral",
  "Ubiquitous",
  "Obsequious",
  "Cacophony",
  "Ennui",
  "Panacea",
  "Mundane",
  "Resilient",
  "Alacrity",
  "Surfeit",
  "Capricious",
  "Esoteric",
  "Gregarious",
  "Hackle",
  "Iconoclast",
  "Juxtapose",
  "Kinetic",
  "Laconic",
  "Maelstrom",
  "Nefarious",
  "Obfuscate",
  "Pariah",
  "Quixotic",
  "Recalcitrant",
  "Sycophant",
  "Taciturn",
  "Umbrage",
  "Venerable",
  "Wistful",
  "Zephyr",
  "Abate",
  "Bolster",
  "Candid",
  "Dirge"
];

export const getNextWord = (currentWord: string): string => {
  const idx = vocabList.indexOf(currentWord);
  if (idx === -1 || idx === vocabList.length - 1) return vocabList[0];
  return vocabList[idx + 1];
};

export const getPrevWord = (currentWord: string): string => {
  const idx = vocabList.indexOf(currentWord);
  if (idx === -1 || idx === 0) return vocabList[vocabList.length - 1];
  return vocabList[idx - 1];
};
