import React, { useState, useEffect, useRef } from 'react';
import { WordData, AppState } from './types';
import { analyzeWord } from './services/geminiService';
import { vocabList, getNextWord, getPrevWord } from './services/vocabList';
import InputSection from './components/InputSection';
import ResultCard from './components/ResultCard';

type Mode = 'search' | 'vocab' | 'favorites';

const STORAGE_KEY_CACHE = 'mnemonic_word_cache_v2';
const STORAGE_KEY_FAVS = 'mnemonic_favorites_list_v2';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [wordData, setWordData] = useState<WordData | null>(null);
  const [error, setError] = useState<string | null>(null);
  
  // Navigation State
  const [mode, setMode] = useState<Mode>('search');
  const [currentVocabWord, setCurrentVocabWord] = useState<string>(vocabList[0]);
  const [currentFavIndex, setCurrentFavIndex] = useState(0);

  // Persistence State
  const [wordCache, setWordCache] = useState<Record<string, WordData>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_CACHE);
      return saved ? JSON.parse(saved) : {};
    } catch (e) { return {}; }
  });
  
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_FAVS);
      return saved ? JSON.parse(saved) : [];
    } catch (e) { return []; }
  });

  const inFlightRequests = useRef<Set<string>>(new Set());

  // Handle Swipe
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);

  const minSwipeDistance = 50;

  const onTouchStart = (e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    setTouchEnd(e.targetTouches[0].clientX);
  };

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > minSwipeDistance;
    const isRightSwipe = distance < -minSwipeDistance;

    if (appState !== AppState.ANALYZING) {
      if (mode === 'vocab') {
        if (isLeftSwipe) handleNextWord();
        else if (isRightSwipe) handlePrevWord();
      } else if (mode === 'favorites' && favorites.length > 0) {
        if (isLeftSwipe) handleNextFav();
        else if (isRightSwipe) handlePrevFav();
      }
    }
  };

  // --- Persistence Helpers ---
  const saveCacheToStorage = (newCache: Record<string, WordData>) => {
    try {
      localStorage.setItem(STORAGE_KEY_CACHE, JSON.stringify(newCache));
    } catch (e) { console.error("Storage full?", e); }
  };

  const saveFavsToStorage = (newFavs: string[]) => {
    localStorage.setItem(STORAGE_KEY_FAVS, JSON.stringify(newFavs));
  };

  const handleUpdateWordData = (newData: WordData) => {
    const word = newData.word;
    const newCache = { ...wordCache, [word]: newData };
    setWordCache(newCache);
    setWordData(newData);
    saveCacheToStorage(newCache);
    
    // Automatically favorite when edited if not already? Optional, but safer to persist
    if (!favorites.includes(word)) {
      const newFavs = [...favorites, word];
      setFavorites(newFavs);
      saveFavsToStorage(newFavs);
    }
  };

  const handleToggleFavorite = (word: string) => {
    let newFavs;
    if (favorites.includes(word)) {
      newFavs = favorites.filter(f => f !== word);
    } else {
      newFavs = [...favorites, word];
    }
    setFavorites(newFavs);
    saveFavsToStorage(newFavs);
  };

  // --- Lazy Preload (Optimized for Quota) ---
  useEffect(() => {
    if (mode !== 'vocab') return;

    // Only preload the immediate next word to conserve quota
    const nextWord = getNextWord(currentVocabWord);
    
    // If already cached or currently fetching, skip
    if (wordCache[nextWord] || inFlightRequests.current.has(nextWord)) return;

    // Wait 3.5 seconds after landing on a word before trying to fetch the next one.
    // If user swipes quickly, this timer clears and we make ZERO requests.
    // This drastically reduces API usage.
    const timer = setTimeout(async () => {
      inFlightRequests.current.add(nextWord);
      try {
        // console.log("Lazy preloading:", nextWord);
        const data = await analyzeWord(nextWord);
        setWordCache(prev => {
          const next = { ...prev, [nextWord]: data };
          saveCacheToStorage(next);
          return next;
        });
      } catch (err) {
        // Silent fail for preload is fine
        console.warn(`Background preload failed for ${nextWord}`, err);
      } finally {
        inFlightRequests.current.delete(nextWord);
      }
    }, 3500);

    return () => clearTimeout(timer);
  }, [currentVocabWord, mode, wordCache]); // wordCache dependency allows check if we already have it

  // --- Core Processing ---
  const processWord = async (word: string) => {
    try {
      setAppState(AppState.ANALYZING);
      setError(null);
      setWordData(null);

      // Check Cache first
      if (wordCache[word]) {
        setWordData(wordCache[word]);
        setAppState(AppState.COMPLETE);
        return;
      }

      // Fetch from API
      const data = await analyzeWord(word);
      
      // Update cache
      const newCache = { ...wordCache, [word]: data };
      setWordCache(newCache);
      saveCacheToStorage(newCache);
      setWordData(data);
      setAppState(AppState.COMPLETE);

    } catch (err: any) {
      console.error(err);
      let msg = err.message || "请求失败，请稍后重试";
      if (msg.includes('429') || msg.includes('quota') || msg.includes('RESOURCE_EXHAUSTED')) {
        msg = "请求过于频繁 (API 配额限制)，正在冷却中，请稍等几秒再试。";
      }
      setError(msg);
      setAppState(AppState.ERROR);
    }
  };

  // --- Handlers ---
  const handleSearch = (word: string) => {
    setMode('search');
    processWord(word);
  };

  const handleVocabMode = () => {
    setMode('vocab');
    processWord(currentVocabWord);
  };

  const handleFavoritesMode = () => {
    setMode('favorites');
    if (favorites.length > 0) {
      setCurrentFavIndex(0);
      processWord(favorites[0]);
    } else {
      setWordData(null);
      setAppState(AppState.IDLE);
    }
  };

  const handleNextWord = () => {
    const next = getNextWord(currentVocabWord);
    setCurrentVocabWord(next);
    processWord(next);
  };

  const handlePrevWord = () => {
    const prev = getPrevWord(currentVocabWord);
    setCurrentVocabWord(prev);
    processWord(prev);
  };

  const handleNextFav = () => {
    if (favorites.length === 0) return;
    const nextIdx = (currentFavIndex + 1) % favorites.length;
    setCurrentFavIndex(nextIdx);
    processWord(favorites[nextIdx]);
  }

  const handlePrevFav = () => {
    if (favorites.length === 0) return;
    const prevIdx = (currentFavIndex - 1 + favorites.length) % favorites.length;
    setCurrentFavIndex(prevIdx);
    processWord(favorites[prevIdx]);
  }

  return (
    <div 
      className="min-h-screen bg-[conic-gradient(at_top_right,_var(--tw-gradient-stops))] from-slate-100 via-yellow-50 to-white py-8 px-4 sm:px-6 lg:px-8 flex flex-col items-center font-sans"
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
    >
      
      {/* Header */}
      <header className="text-center mb-8 animate-fade-in-down w-full max-w-4xl flex flex-col items-center">
        <div className="flex items-center justify-center gap-2 mb-4">
           <div className="inline-block p-3 rounded-full bg-yellow-400 shadow-lg text-slate-900">
              <i className="fas fa-brain text-3xl"></i>
           </div>
        </div>
        
        <h1 className="text-4xl md:text-5xl font-black text-slate-900 font-display mb-2 tracking-tight">
          谐音单词王
        </h1>
        <p className="text-lg text-slate-500 font-medium">
          有趣 · 荒诞 · 瞬间记忆
        </p>

        {/* Mode Toggle Tabs */}
        <div className="mt-6 flex bg-slate-200 p-1 rounded-full relative shadow-inner overflow-hidden flex-wrap justify-center">
          <button 
            onClick={() => setMode('search')}
            className={`px-4 sm:px-6 py-2 rounded-full text-xs sm:text-sm font-bold transition-all z-10 ${mode === 'search' ? 'bg-white shadow text-slate-900' : 'text-slate-500 hover:text-slate-700'}`}
          >
            自由搜索
          </button>
          <button 
             onClick={handleVocabMode}
             className={`px-4 sm:px-6 py-2 rounded-full text-xs sm:text-sm font-bold transition-all z-10 ${mode === 'vocab' ? 'bg-white shadow text-slate-900' : 'text-slate-500 hover:text-slate-700'}`}
          >
            高阶词本 (3000词)
          </button>
          <button 
             onClick={handleFavoritesMode}
             className={`px-4 sm:px-6 py-2 rounded-full text-xs sm:text-sm font-bold transition-all z-10 ${mode === 'favorites' ? 'bg-white shadow text-pink-500' : 'text-slate-500 hover:text-pink-400'}`}
          >
            我的收藏 ({favorites.length})
          </button>
        </div>
      </header>

      {/* Input or Navigation Info */}
      {mode === 'search' && (
        <InputSection 
          onSearch={handleSearch} 
          isLoading={appState === AppState.ANALYZING} 
        />
      )}

      {mode === 'vocab' && (
        <div className="mb-8 flex items-center gap-4">
           <button onClick={handlePrevWord} className="w-10 h-10 rounded-full bg-white shadow flex items-center justify-center hover:bg-slate-50 active:scale-95">
             <i className="fas fa-chevron-left text-slate-400"></i>
           </button>
           <div className="text-slate-500 font-mono font-bold">
             {vocabList.indexOf(currentVocabWord) + 1} / {vocabList.length}
           </div>
           <button onClick={handleNextWord} className="w-10 h-10 rounded-full bg-white shadow flex items-center justify-center hover:bg-slate-50 active:scale-95">
             <i className="fas fa-chevron-right text-slate-400"></i>
           </button>
           <p className="text-xs text-slate-400 absolute bottom-0 translate-y-6 w-full text-center">左右滑动切换 (智能缓冲)</p>
        </div>
      )}

      {mode === 'favorites' && favorites.length > 0 && (
         <div className="mb-8 flex items-center gap-4">
           <button onClick={handlePrevFav} className="w-10 h-10 rounded-full bg-white shadow flex items-center justify-center hover:bg-pink-50 active:scale-95 text-pink-400">
             <i className="fas fa-chevron-left"></i>
           </button>
           <div className="text-pink-500 font-mono font-bold">
             {currentFavIndex + 1} / {favorites.length}
           </div>
           <button onClick={handleNextFav} className="w-10 h-10 rounded-full bg-white shadow flex items-center justify-center hover:bg-pink-50 active:scale-95 text-pink-400">
             <i className="fas fa-chevron-right"></i>
           </button>
         </div>
      )}

      {mode === 'favorites' && favorites.length === 0 && (
        <div className="bg-white p-8 rounded-2xl shadow-lg text-center max-w-md border-4 border-dashed border-pink-100">
          <i className="fas fa-heart-broken text-4xl text-pink-200 mb-4"></i>
          <p className="text-slate-500 font-bold">暂无收藏</p>
          <p className="text-slate-400 text-sm mt-2">点击单词卡片右上角的爱心 ❤️ 即可加入收藏夹</p>
        </div>
      )}

      {/* Error Message */}
      {error && (
        <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded-xl mb-8 max-w-xl w-full animate-shake shadow-sm">
          <div className="flex">
            <div className="flex-shrink-0">
              <i className="fas fa-exclamation-circle text-red-400"></i>
            </div>
            <div className="ml-3">
              <p className="text-sm font-bold text-red-800">出错了</p>
              <p className="text-sm text-red-700">{error}</p>
              <button 
                onClick={() => processWord(mode === 'vocab' ? currentVocabWord : (mode === 'favorites' && favorites.length > 0 ? favorites[currentFavIndex] : ''))}
                className="mt-2 text-xs font-bold text-red-600 underline hover:text-red-800"
              >
                点击重试
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Results */}
      {(wordData || appState === AppState.ANALYZING) && (
        <div className="w-full">
           {wordData && appState !== AppState.ANALYZING ? (
             <ResultCard 
               data={wordData} 
               showNav={mode !== 'search'}
               onNext={mode === 'vocab' ? handleNextWord : handleNextFav}
               onPrev={mode === 'vocab' ? handlePrevWord : handlePrevFav}
               onToggleFavorite={handleToggleFavorite}
               isFavorite={favorites.includes(wordData.word)}
               onUpdateData={handleUpdateWordData}
             />
           ) : (
             // Loading Skeleton
             <div className="w-full max-w-4xl mx-auto bg-white rounded-[2rem] shadow-xl border-4 border-yellow-50 p-12 flex flex-col items-center justify-center min-h-[500px] animate-pulse">
                <div className="w-20 h-20 bg-yellow-100 rounded-full mb-6 flex items-center justify-center">
                   <div className="w-10 h-10 border-4 border-yellow-400 border-t-transparent rounded-full animate-spin"></div>
                </div>
                <div className="h-8 bg-slate-100 rounded-full w-48 mb-4"></div>
                <div className="h-4 bg-slate-100 rounded-full w-64 mb-12"></div>
                
                <div className="flex gap-4 mb-8 w-full max-w-lg justify-center">
                  <div className="h-32 w-24 bg-red-50 rounded-xl border-b-4 border-red-100"></div>
                  <div className="h-32 w-24 bg-blue-50 rounded-xl border-b-4 border-blue-100"></div>
                  <div className="h-32 w-24 bg-green-50 rounded-xl border-b-4 border-green-100"></div>
                </div>
                
                <p className="mt-8 text-slate-400 font-bold tracking-widest text-sm uppercase">正在生成 5 种脑洞记忆法...</p>
             </div>
           )}
        </div>
      )}

      {/* Footer */}
      <footer className="mt-auto pt-16 text-center text-slate-400 text-xs font-semibold uppercase tracking-widest pb-6">
        <p>Powered by Google Gemini 2.5 Flash</p>
      </footer>
    </div>
  );
};

export default App;